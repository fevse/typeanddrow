# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['typeanddrow', 'typeanddrow.scripts']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['draw-cat = typeanddrow.scripts.draw_cat:main',
                     'draw-dog = typeanddrow.scripts.draw_dog:main']}

setup_kwargs = {
    'name': 'typeanddrow',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'fevse',
    'author_email': 'fedulov.v.s@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
