import time

def main():
    time.sleep(1)
    print('  /~~~\\')
    time.sleep(1)
    print(' //^ ^\\\\')
    time.sleep(1)
    print('(/(_*_)\\)')
    time.sleep(1)
    print("_/''*''\\_")
    time.sleep(1)
    print('(/_)^(_\\)')

if __name__=='__main__':
    main()
